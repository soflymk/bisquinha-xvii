import express from 'express';
import { createServer } from 'http';
import { Server } from 'socket.io';
import path from 'path';
import session from 'express-session';
import cookieParser from 'cookie-parser';
import bcrypt from 'bcryptjs';
import { v4 as uuidv4 } from 'uuid';
import sqlite3 from 'sqlite3';
import { BiscaEngine } from './src/lib/engine';
import { Card, GameState, RoomStatus, User, Suit, ChatMessage } from './src/lib/types';

// Database Setup
console.log("Initializing database...");
const db = new sqlite3.Database('bisca.db', (err) => {
  if (err) console.error("Database open error:", err);
  else console.log("Database opened successfully");
});

db.serialize(() => {
  console.log("Creating tables...");
  db.run(`CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY,
    username TEXT UNIQUE,
    password_hash TEXT,
    nickname TEXT,
    role TEXT DEFAULT 'USER',
    is_active INTEGER DEFAULT 1,
    created_at INTEGER
  )`, (err) => {
    if (err) console.error("Error creating users table:", err);
  });

  db.run(`CREATE TABLE IF NOT EXISTS rooms (
    id TEXT PRIMARY KEY,
    name TEXT,
    owner_id TEXT,
    score_goal INTEGER DEFAULT 5,
    time_limit INTEGER DEFAULT 0,
    status TEXT DEFAULT 'WAITING',
    created_at INTEGER
  )`, () => {
    // Limpeza de salas que ficaram "órfãs" de um processo anterior
    console.log("Cleaning up orphaned rooms...");
    db.run("DELETE FROM rooms WHERE status != 'FINISHED'");
  });

  // Admin padrão
  const adminId = 'admin-uuid';
  db.get('SELECT * FROM users WHERE username = ?', ['admin'], (err, row) => {
    if (err) console.error("Error checking for admin:", err);
    if (!row) {
      console.log("Creating default admin user...");
      const hash = bcrypt.hashSync('admin123', 10);
      db.run('INSERT INTO users (id, username, password_hash, nickname, role, is_active, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)', 
        [adminId, 'admin', hash, 'Administrador', 'ADMIN', 1, Date.now()], (err) => {
          if (err) console.error("Error creating admin user:", err);
          else console.log("Admin user created successfully!");
        });
    } else {
      console.log("Admin user already exists.");
    }
  });
});

const app = express();
const httpServer = createServer(app);
const io = new Server(httpServer, {
  cors: { origin: '*' }
});

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());

const sessionMiddleware = session({
  secret: 'bisca-secret-key-capixaba',
  resave: false,
  saveUninitialized: false,
  cookie: { secure: false, maxAge: 24 * 60 * 60 * 1000 }
});

app.use(sessionMiddleware);

// Middleware para disponibilizar session no socket
io.engine.use(sessionMiddleware);

// Estado das salas em memória para rapidez (Multiplayer)
const activeGames: Record<string, {
  gameState: GameState;
  config: { scoreGoal: number; timeLimit: number };
  slots: (string | null)[]; // userIds
  ownerId: string; // The person who can start the game
  nicknames: Record<string, string>;
  teams: Record<string, 1 | 2>;
  reconnectionTimers: Record<string, NodeJS.Timeout>;
  swapRequests: Record<string, { from: string, to: string, expires: number }>;
  lastCutterIdx: number; // For rotation
  chat: ChatMessage[];
}> = {};

const cleanupRoom = (roomId: string, io: Server) => {
  const game = activeGames[roomId];
  if (!game) return;

  if (game.slots.every(s => s === null)) {
    console.log(`Closing empty room: ${roomId}`);
    delete activeGames[roomId];
    db.run('DELETE FROM rooms WHERE id = ?', [roomId]);
    io.emit('rooms_updated'); 
  } else {
    // Reassign owner if previous owner is gone
    if (!game.slots.includes(game.ownerId)) {
      const nextOwner = game.slots.find(s => s !== null);
      if (nextOwner) game.ownerId = nextOwner;
    }

    io.to(roomId).emit('room_update', { 
      slots: game.slots, 
      nicknames: game.nicknames, 
      teams: game.teams,
      ownerId: game.ownerId
    });
  }
};

// --- API ROTAS ---

// Auth
app.post('/api/login', (req: any, res) => {
  const { username, password } = req.body;
  db.get('SELECT * FROM users WHERE username = ?', [username], (err, user: any) => {
    if (err || !user) return res.status(401).json({ error: 'Usuário não encontrado' });
    if (!user.is_active) return res.status(403).json({ error: 'Conta inativa. Entre em contato com o administrador.' });
    
    if (bcrypt.compareSync(password, user.password_hash)) {
      req.session.userId = user.id;
      req.session.role = user.role;
      req.session.username = user.username;
      res.json({ message: 'Login realizado com sucesso', user: { id: user.id, username: user.username, nickname: user.nickname, role: user.role } });
    } else {
      res.status(401).json({ error: 'Senha incorreta' });
    }
  });
});

app.get('/api/me', (req: any, res) => {
  if (!req.session.userId) return res.status(401).json({ error: 'Não logado' });
  db.get('SELECT id, username, nickname, role, is_active FROM users WHERE id = ?', [req.session.userId], (err, user) => {
    if (err || !user) return res.status(404).json({ error: 'Usuário não encontrado' });
    res.json(user);
  });
});

app.post('/api/logout', (req: any, res) => {
  req.session.destroy((err: any) => {
    if (err) return res.status(500).json({ error: 'Erro ao fazer logout' });
    res.json({ message: 'Logout realizado' });
  });
});

// Admin
app.get('/api/admin/users', (req: any, res) => {
  if (req.session.role !== 'ADMIN') return res.status(403).json({ error: 'Acesso negado' });
  db.all('SELECT id, username, nickname, role, is_active, created_at FROM users', (err, rows) => {
    if (err) return res.status(500).json({ error: 'Erro ao buscar usuários' });
    res.json(rows || []);
  });
});

app.post('/api/admin/users/toggle', (req: any, res) => {
  if (req.session.role !== 'ADMIN') return res.status(403).json({ error: 'Acesso negado' });
  const { userId, active } = req.body;
  db.run('UPDATE users SET is_active = ? WHERE id = ?', [active ? 1 : 0, userId], () => {
    res.json({ success: true });
  });
});

app.post('/api/admin/users/create', (req: any, res) => {
  if (req.session.role !== 'ADMIN') return res.status(403).json({ error: 'Acesso negado' });
  const { username, nickname, password } = req.body;
  
  if (!username || !nickname || !password) {
    return res.status(400).json({ error: 'Campos obrigatórios ausentes' });
  }

  db.get('SELECT * FROM users WHERE username = ?', [username], (err, row) => {
    if (row) return res.status(400).json({ error: 'Usuário já existe' });
    
    const id = uuidv4();
    const hash = bcrypt.hashSync(password, 10);
    db.run('INSERT INTO users (id, username, password_hash, nickname, role, is_active, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)', 
      [id, username, hash, nickname, 'USER', 1, Date.now()], (err) => {
        if (err) return res.status(500).json({ error: 'Erro ao criar usuário' });
        res.json({ success: true });
      });
  });
});

app.post('/api/admin/users/promote', (req: any, res) => {
  if (req.session.role !== 'ADMIN') return res.status(403).json({ error: 'Acesso negado' });
  const { userId, role } = req.body; // 'ADMIN' or 'USER'
  db.run('UPDATE users SET role = ? WHERE id = ?', [role, userId], (err) => {
    if (err) return res.status(500).json({ error: 'Erro ao atualizar nível' });
    res.json({ success: true });
  });
});

app.post('/api/admin/users/reset-password', (req: any, res) => {
  if (req.session.role !== 'ADMIN') return res.status(403).json({ error: 'Acesso negado' });
  const { userId, newPassword } = req.body;
  if (!newPassword || newPassword.length < 4) return res.status(400).json({ error: 'Senha curta demais' });
  
  db.run('UPDATE users SET password_hash = ? WHERE id = ?', [bcrypt.hashSync(newPassword, 10), userId], (err) => {
    if (err) return res.status(500).json({ error: 'Erro ao redefinir senha' });
    res.json({ success: true });
  });
});

app.post('/api/me/change-password', (req: any, res) => {
  if (!req.session.userId) return res.status(401).json({ error: 'Não logado' });
  const { currentPassword, newPassword } = req.body;
  if (!newPassword || newPassword.length < 4) return res.status(400).json({ error: 'Nova senha curta demais' });

  db.get('SELECT password_hash FROM users WHERE id = ?', [req.session.userId], (err, user: any) => {
    if (err || !user) return res.status(404).json({ error: 'Usuário não encontrado' });
    if (!bcrypt.compareSync(currentPassword, user.password_hash)) return res.status(400).json({ error: 'Senha atual incorreta' });
    
    db.run('UPDATE users SET password_hash = ? WHERE id = ?', [bcrypt.hashSync(newPassword, 10), req.session.userId], (err) => {
      if (err) return res.status(500).json({ error: 'Erro ao alterar senha' });
      res.json({ success: true });
    });
  });
});

app.post('/api/me/update-nickname', (req: any, res) => {
  if (!req.session.userId) return res.status(401).json({ error: 'Não logado' });
  const { nickname } = req.body;
  if (!nickname || nickname.length < 2) return res.status(400).json({ error: 'Apelido inválido' });

  db.run('UPDATE users SET nickname = ? WHERE id = ?', [nickname, req.session.userId], (err) => {
    if (err) return res.status(500).json({ error: 'Erro ao atualizar apelido' });
    res.json({ success: true });
  });
});

// Admin Rooms
app.get('/api/admin/rooms/active', (req: any, res) => {
  if (req.session.role !== 'ADMIN') return res.status(403).json({ error: 'Acesso negado' });
  
  db.all('SELECT * FROM rooms', (err, rows: any[]) => {
    if (err) return res.status(500).json([]);
    const rooms = rows.map(r => ({
      ...r,
      playerCount: (activeGames[r.id] && activeGames[r.id].slots.filter(s => s !== null).length) || 0,
      active: !!activeGames[r.id]
    }));
    res.json(rooms);
  });
});

app.post('/api/admin/rooms/close', (req: any, res) => {
  if (req.session.role !== 'ADMIN') return res.status(403).json({ error: 'Acesso negado' });
  const { roomId } = req.body;

  const game = activeGames[roomId];
  if (game) {
    io.to(roomId).emit('game_aborted', { reason: 'Esta sala foi encerrada por um administrador do Quartel General.' });
    delete activeGames[roomId];
  }
  
  db.run('DELETE FROM rooms WHERE id = ?', [roomId], (err) => {
    if (err) return res.status(500).json({ error: 'Erro ao fechar sala' });
    io.emit('rooms_updated');
    res.json({ success: true });
  });
});

// Rooms
app.get('/api/rooms', (req, res) => {
  db.all('SELECT * FROM rooms WHERE status != ?', ['FINISHED'], (err, rows: any[]) => {
    if (err) return res.status(500).json([]);
    const roomsWithCount = rows.map(r => ({
      ...r,
      playerCount: (activeGames[r.id] && activeGames[r.id].slots.filter(s => s !== null).length) || 0
    }));
    res.json(roomsWithCount);
  });
});

app.post('/api/rooms/create', (req: any, res) => {
  if (!req.session.userId) return res.status(401).json({ error: 'Não logado' });
  const { name, scoreGoal, timeLimit } = req.body;
  const roomId = uuidv4();
  
  db.run('INSERT INTO rooms (id, name, owner_id, score_goal, time_limit, created_at) VALUES (?, ?, ?, ?, ?, ?)',
    [roomId, name, req.session.userId, scoreGoal, timeLimit, Date.now()], (err) => {
      if (err) return res.status(500).json({ error: 'Erro ao criar sala' });
      
      activeGames[roomId] = {
        gameState: null as any,
        config: { scoreGoal: parseInt(scoreGoal), timeLimit: parseInt(timeLimit) || 0 },
        slots: [null, null, null, null],
        ownerId: req.session.userId,
        nicknames: {},
        teams: {},
        reconnectionTimers: {},
        swapRequests: {},
        lastCutterIdx: -1,
        chat: []
      };
      
      res.json({ roomId });
    });
});

// --- SOCKET HANDLERS ---

io.on('connection', (socket: any) => {
  const session = socket.request.session;
  if (!session || !session.userId) return;

  const userId = session.userId;

  socket.on('join_room', async (roomId: string) => {
    if (!activeGames[roomId]) {
      // Tentar recuperar do banco se servidor resetou? Para esse projeto básico, assumimos memória.
      socket.emit('error', 'Sala não encontrada');
      return;
    }

    const game = activeGames[roomId];
    socket.join(roomId);

    // Se já estiver na sala ou reconectar
    let slotIdx = game.slots.indexOf(userId);
    if (slotIdx === -1) {
      // Tentar sentar no primeiro lugar vago
      slotIdx = game.slots.indexOf(null);
      if (slotIdx !== -1) {
        game.slots[slotIdx] = userId;
        // Definir time: 0 e 2 são Time 1, 1 e 3 são Time 2
        game.teams[userId] = (slotIdx % 2 === 0) ? 1 : 2;
        
        // Buscar nickname
        db.get('SELECT nickname FROM users WHERE id = ?', [userId], (err, row: any) => {
          game.nicknames[userId] = row.nickname;
          io.to(roomId).emit('room_update', {
            slots: game.slots,
            nicknames: game.nicknames,
            teams: game.teams,
            ownerId: game.ownerId
          });
        });
      } else {
        socket.emit('error', 'Sala cheia');
        return;
      }
    } else {
      // Limpar timer de queda
      if (game.reconnectionTimers[userId]) {
        clearTimeout(game.reconnectionTimers[userId]);
        delete game.reconnectionTimers[userId];
        io.to(roomId).emit('player_reconnected');
        io.to(roomId).emit('system_message', `${game.nicknames[userId]} reconectou.`);
      }
    }

    socket.emit('init_sync', {
      gameState: game.gameState,
      config: game.config,
      slots: game.slots,
      nicknames: game.nicknames,
      teams: game.teams,
      ownerId: game.ownerId,
      chat: game.chat,
      userId: userId
    });
  });

  socket.on('start_game', (roomId: string) => {
    const game = activeGames[roomId];
    if (!game) return;
    // Validar se é o owner e se há 4 jogadores
    if (game.ownerId !== userId) {
      return socket.emit('error', 'Apenas o chefe da sala pode iniciar a partida.');
    }
    if (game.slots.filter(s => s !== null).length !== 4) {
      return socket.emit('error', 'Necessário 4 jogadores para iniciar.');
    }

    const userIds = game.slots as string[];
    const posMap: Record<string, number> = {};
    const teamMap: Record<string, 1 | 2> = {};
    userIds.forEach((id, idx) => {
      posMap[id] = idx;
      teamMap[id] = (idx % 2 === 0) ? 1 : 2;
    });

    game.gameState = BiscaEngine.initGame(userIds, posMap, teamMap);
    game.gameState.status = 'SHUFFLING';
    game.gameState.lastVazaWinner = null;
    
    io.to(roomId).emit('game_update', game.gameState);
    db.run('UPDATE rooms SET status = ? WHERE id = ?', ['IN_GAME', roomId]);

    // Shuffling animation delay
    setTimeout(() => {
      if (!activeGames[roomId] || !activeGames[roomId].gameState) return;
      const g = activeGames[roomId];
      
      // Rotate cutter
      g.lastCutterIdx = (g.lastCutterIdx + 1) % 4;
      if (g.lastCutterIdx === -1) g.lastCutterIdx = 3;
      
      const cutterId = g.slots[g.lastCutterIdx]!;
      g.gameState.cutterId = cutterId;
      g.gameState.status = 'CUTTING';
      
      const cuttingCards = [];
      const tempDeck = [...g.gameState.deck];
      for (let i = 0; i < 5; i++) {
        cuttingCards.push(tempDeck.pop()!);
      }
      g.gameState.cuttingCards = cuttingCards;
      g.gameState.deck = tempDeck;
      
      io.to(roomId).emit('game_update', g.gameState);
      io.to(roomId).emit('system_message', `${g.nicknames[cutterId]} está cortando o baralho.`);
    }, 2000);
  });

  socket.on('select_corte', ({ roomId, cardId, isBater }: { roomId: string, cardId?: string, isBater?: boolean }) => {
    const game = activeGames[roomId];
    if (!game || !game.gameState || game.gameState.status !== 'CUTTING') return;
    if (game.gameState.cutterId !== userId) return;

    const state = game.gameState;
    
    if (isBater) {
      state.isCopas = true;
      state.trumpSuit = 'Copas';
      state.cuttingCards = [];
      io.to(roomId).emit('system_message', `${game.nicknames[userId]} BATEU EM COPAS!`);
    } else {
      const card = state.cuttingCards.find(c => c.id === cardId);
      if (!card) return;
      state.visibleCorte = card;
      state.trumpSuit = card.suit;

      if (card.value === 'A' || card.value === '7') {
        state.trumpSuit = BiscaEngine.getSuitInversion(card.suit);
      }
      
      io.to(roomId).emit('game_update', state);
      // Wait for reveal animation before proceeding
    }

    setTimeout(() => {
      if (!activeGames[roomId] || !activeGames[roomId].gameState) return;
      const g = activeGames[roomId];
      const s = g.gameState;

      if (!s.isCopas) {
        s.deck.push(...s.cuttingCards.filter(c => c.id !== cardId));
        s.cuttingCards = [];
        s.deck = BiscaEngine.shuffle(s.deck);
        
        if (s.visibleCorte && s.visibleCorte.value !== 'A' && s.visibleCorte.value !== '7') {
          const idx = s.deck.findIndex(c => c.id === s.visibleCorte!.id);
          if (idx !== -1) s.deck.splice(idx, 1);
          s.deck.unshift(s.visibleCorte);
        }
      } else {
        s.deck.push(...s.cuttingCards);
        s.cuttingCards = [];
        s.deck = BiscaEngine.shuffle(s.deck);
      }

      s.status = 'SHUFFLING';
      io.to(roomId).emit('game_update', s);

      setTimeout(() => {
        if (!activeGames[roomId] || !activeGames[roomId].gameState) return;
        const g2 = activeGames[roomId];
        const s2 = g2.gameState;
        s2.status = 'DEALING';
        io.to(roomId).emit('game_update', s2);

        const cutterIdx = g2.slots.indexOf(s2.cutterId!);
        const startIdx = (cutterIdx + 1) % 4;
        
        let dealStep = 0;
        const dealInterval = setInterval(() => {
          if (!activeGames[g2.id] || !activeGames[g2.id].gameState) {
            clearInterval(dealInterval);
            return;
          }
          const currState = activeGames[g2.id].gameState;
          const targetIdx = (startIdx + dealStep) % 4;
          const targetUserId = g2.slots[targetIdx]!;
          
          const card = currState.deck.pop()!;
          currState.players[targetUserId].hand.push(card);
          currState.lastDealtUserId = targetUserId;
          
          io.to(g2.id).emit('game_update', currState);
          
          dealStep++;
          if (dealStep === 12) {
            clearInterval(dealInterval);
            currState.status = 'IN_GAME';
            currState.lastDealtUserId = null;
            currState.currentTurn = g2.slots[startIdx]!;
            io.to(g2.id).emit('game_update', currState);
            io.to(g2.id).emit('system_message', `Cartas dadas! Começa ${g2.nicknames[currState.currentTurn]}.`);
          }
        }, 80);
      }, 400);
    }, isBater ? 0 : 800);
  });

  const triggerNextHand = (roomId: string) => {
    const game = activeGames[roomId];
    if (!game || !game.gameState) return;
    
    const state = game.gameState;
    state.deck = BiscaEngine.shuffle(BiscaEngine.createDeck());
    state.vaza = [];
    state.isCopas = false;
    state.visibleCorte = null;
    state.roundCount = 0;
    state.corteSwapDone = false;
    state.heleyOccurred = false;
    state.status = 'SHUFFLING';
    
    // Reset individual hand points
    for (const pid in state.players) {
      state.players[pid].hand = [];
      state.players[pid].vazaPoints = 0;
    }

    io.to(roomId).emit('game_update', state);

    setTimeout(() => {
      if (!activeGames[roomId]) return;
      game.lastCutterIdx = (game.lastCutterIdx + 1) % 4;
      const cutterId = game.slots[game.lastCutterIdx]!;
      game.gameState.cutterId = cutterId;
      game.gameState.status = 'CUTTING';
      
      const cuttingCards = [];
      for (let i = 0; i < 5; i++) {
        cuttingCards.push(game.gameState.deck.pop()!);
      }
      game.gameState.cuttingCards = cuttingCards;
      
      io.to(roomId).emit('game_update', game.gameState);
      io.to(roomId).emit('system_message', `${game.nicknames[cutterId]} está cortando o baralho.`);
    }, 2000);
  };

  socket.on('request_swap', ({ roomId, toIdx }: { roomId: string, toIdx: number }) => {
    const game = activeGames[roomId];
    if (!game || game.gameState) return; // Não troca em jogo
    const fromIdx = game.slots.indexOf(userId);
    const targetUserId = game.slots[toIdx];

    if (!targetUserId) {
      // Slot vazio, troca direta
      game.slots[fromIdx] = null;
      game.slots[toIdx] = userId;
      game.teams[userId] = (toIdx % 2 === 0) ? 1 : 2;
      io.to(roomId).emit('room_update', { slots: game.slots, nicknames: game.nicknames, teams: game.teams, ownerId: game.ownerId });
    } else {
      // Enviar pedido
      io.to(roomId).emit('swap_request_received', { from: userId, fromNickname: game.nicknames[userId], toIdx, toUserId: targetUserId });
    }
  });

  socket.on('accept_swap', ({ roomId, fromUserId }: { roomId: string, fromUserId: string }) => {
    const game = activeGames[roomId];
    if (!game) return;
    const fromIdx = game.slots.indexOf(fromUserId);
    const toIdx = game.slots.indexOf(userId);

    if (fromIdx !== -1 && toIdx !== -1) {
      game.slots[fromIdx] = userId;
      game.slots[toIdx] = fromUserId;
      game.teams[userId] = (fromIdx % 2 === 0) ? 1 : 2;
      game.teams[fromUserId] = (toIdx % 2 === 0) ? 1 : 2;
      io.to(roomId).emit('room_update', { slots: game.slots, nicknames: game.nicknames, teams: game.teams, ownerId: game.ownerId });
      io.to(roomId).emit('system_message', `${game.nicknames[userId]} e ${game.nicknames[fromUserId]} trocaram de lugar.`);
    }
  });

  socket.on('play_card', ({ roomId, cardId }: { roomId: string, cardId: string }) => {
    const game = activeGames[roomId];
    if (!game || !game.gameState) return;
    const state = game.gameState;

    if (state.currentTurn !== userId) return;

    const player = state.players[userId];
    const cardIdx = player.hand.findIndex(c => c.id === cardId);
    if (cardIdx === -1) return;

    const card = player.hand.splice(cardIdx, 1)[0];
    state.vaza.push({ userId, card });

    // Próximo turno
    const turnIdx = game.slots.indexOf(userId);
    const nextUserId = game.slots[(turnIdx + 1) % 4] as string;
    state.currentTurn = nextUserId;

    // Se vaza completa (4 cartas)
    if (state.vaza.length === 4) {
      const winnerId = BiscaEngine.resolveVaza(state.vaza, state.trumpSuit!);
      state.lastWinner = winnerId;
      state.currentTurn = winnerId;
      
      const vazaCards = state.vaza.map(v => v.card);
      
      // Checar Heley
      // Regra: Ás do trunfo jogado após o 7 do trunfo na mesma vaza
      const sevenIdx = state.vaza.findIndex(v => v.card.suit === state.trumpSuit && v.card.value === '7');
      const aceIdx = state.vaza.findIndex(v => v.card.suit === state.trumpSuit && v.card.value === 'A');
      if (sevenIdx !== -1 && aceIdx !== -1 && aceIdx > sevenIdx) {
        state.heleyOccurred = true;
        const heleyPoints = state.isCopas ? 2 : 1;
        if (state.players[winnerId].team === 1) state.gameScore.team1 += heleyPoints;
        else state.gameScore.team2 += heleyPoints;
        io.to(roomId).emit('heley_notice', { team: state.players[winnerId].team, points: heleyPoints });
      }

      state.players[winnerId].vazaPoints += BiscaEngine.calculateHandPoints(vazaCards);
      
      // Broadcast vaza result antes de limpar
      io.to(roomId).emit('vaza_resolved', { winnerId, vaza: state.vaza });
      state.vaza = [];
      state.roundCount++;

      // Comprar cartas
      if (state.deck.length > 0) {
        // O vencedor compra primeiro, depois segue a ordem
        const order = [];
        const winIdx = game.slots.indexOf(winnerId);
        for (let i = 0; i < 4; i++) {
          order.push(game.slots[(winIdx + i) % 4]);
        }
        for (const pid of order) {
          if (state.deck.length > 0) {
            state.players[pid as string].hand.push(state.deck.pop()!);
          }
        }
      }

      // Fim da mão?
      if (state.players[userId].hand.length === 0 && state.deck.length === 0) {
        // Contar pontos
        const team1Points = Object.values(state.players).filter(p => p.team === 1).reduce((a, b) => a + b.vazaPoints, 0);
        const team2Points = Object.values(state.players).filter(p => p.team === 2).reduce((a, b) => a + b.vazaPoints, 0);
        
        let winnerTeam: 1 | 2 = team1Points > team2Points ? 1 : 2;
        let pointsWon = state.isCopas ? 2 : 1;

        // Regra do Capote: perdedor <= 30 pontos em cartas
        const loserPoints = winnerTeam === 1 ? team2Points : team1Points;
        if (loserPoints <= 30) {
          pointsWon = state.isCopas ? 3 : 2;
          io.to(roomId).emit('system_message', `CAPOTE! A dupla perdedora fez apenas ${loserPoints} pontos.`);
        }

        if (winnerTeam === 1) state.gameScore.team1 += pointsWon;
        else state.gameScore.team2 += pointsWon;

        io.to(roomId).emit('hand_finished', {
          team1Points,
          team2Points,
          winnerTeam,
          pointsWon,
          newGameScore: state.gameScore
        });

        // Fim da partida?
        if (state.gameScore.team1 >= game.config.scoreGoal || state.gameScore.team2 >= game.config.scoreGoal) {
          state.status = 'FINISHED';
          db.run('UPDATE rooms SET status = ? WHERE id = ?', ['FINISHED', roomId]);
          io.to(roomId).emit('game_finished', { winnerTeam: state.gameScore.team1 >= game.config.scoreGoal ? 1 : 2 });
        } else {
          // Delay briefly to allow players to see the result
          setTimeout(() => triggerNextHand(roomId), 5000);
        }
      }
    }

    io.to(roomId).emit('game_update', state);
  });

  socket.on('send_chat', ({ roomId, text }: { roomId: string, text: string }) => {
    const game = activeGames[roomId];
    if (!game || !text.trim()) return;

    const message: ChatMessage = {
      id: uuidv4(),
      userId: userId,
      nickname: game.nicknames[userId] || 'Sistema',
      text: text.slice(0, 200), // Limite de caracteres
      timestamp: Date.now()
    };

    game.chat.push(message);
    if (game.chat.length > 50) game.chat.shift(); // Manter apenas as últimas 50 mensagems

    io.to(roomId).emit('chat_message', message);
  });

  socket.on('bater_copas', (roomId: string) => {
    const game = activeGames[roomId];
    if (!game || !game.gameState) return;
    if (game.gameState.roundCount > 0 || game.gameState.vaza.length > 0) return;

    game.gameState.isCopas = true;
    game.gameState.trumpSuit = 'Copas';
    io.to(roomId).emit('system_message', `${game.nicknames[userId]} BATEU EM COPAS! Mão vale dobrado.`);
    io.to(roomId).emit('game_update', game.gameState);
  });

  socket.on('swap_corte_2', (roomId: string) => {
    const game = activeGames[roomId];
    if (!game || !game.gameState || game.gameState.corteSwapDone) return;
    if (game.gameState.roundCount > 0) return;

    const state = game.gameState;
    const player = state.players[userId];
    const twoIdx = player.hand.findIndex(c => c.value === '2' && c.suit === state.visibleCorte?.suit);
    
    if (twoIdx !== -1 && state.visibleCorte) {
      const twoCard = player.hand.splice(twoIdx, 1)[0];
      const oldCorte = state.visibleCorte;
      
      // Troca
      player.hand.push(oldCorte);
      state.visibleCorte = twoCard;
      state.corteSwapDone = true;
      
      // Atualizar no fundo do baralho se ele ainda estiver lá
      const deckIdx = state.deck.findIndex(c => c.id === oldCorte.id);
      if (deckIdx !== -1) {
        state.deck[deckIdx] = twoCard;
      }

      io.to(roomId).emit('system_message', `${game.nicknames[userId]} trocou o 2 pela carta do corte.`);
      io.to(roomId).emit('game_update', state);
    }
  });

  socket.on('leave_room', (roomId: string) => {
    const game = activeGames[roomId];
    if (!game) return;

    const idx = game.slots.indexOf(userId);
    if (idx !== -1) {
      game.slots[idx] = null;
      delete game.nicknames[userId];
      delete game.teams[userId];
      
      socket.leave(roomId);
      cleanupRoom(roomId, io);
      io.to(roomId).emit('system_message', `${session.username} saiu da sala.`);
    }
  });

  socket.on('disconnect', () => {
    // Achar em quais salas este user estava
    for (const roomId in activeGames) {
      const game = activeGames[roomId];
      if (game.slots.includes(userId)) {
        if (game.gameState && game.gameState.status === 'IN_GAME') {
          io.to(roomId).emit('player_disconnected', { 
            nickname: game.nicknames[userId] || 'Jogador',
            timeout: 30000 
          });
          
          game.reconnectionTimers[userId] = setTimeout(() => {
            io.to(roomId).emit('game_aborted', { reason: 'Jogador abandonou a partida.' });
            game.gameState = null as any;
            db.run('UPDATE rooms SET status = ? WHERE id = ?', ['WAITING', roomId]);
            
            // Após abortar, checar se a sala ficou vazia (pode ter sobrado ninguém se todos saíram enquanto esperavam)
            const idx = game.slots.indexOf(userId);
            if (idx !== -1) game.slots[idx] = null;
            cleanupRoom(roomId, io);
          }, 30000);
        } else {
          // Apenas remover do slot se ainda não começou
          const idx = game.slots.indexOf(userId);
          game.slots[idx] = null;
          delete game.nicknames[userId];
          delete game.teams[userId];
          
          cleanupRoom(roomId, io);
        }
      }
    }
  });
});

// Vite middleware for development
if (process.env.NODE_ENV !== "production") {
  const { createServer: createViteServer } = await import("vite");
  const vite = await createViteServer({
    server: { middlewareMode: true },
    appType: "spa",
  });
  app.use(vite.middlewares);
} else {
  const distPath = path.join(process.cwd(), 'dist');
  app.use(express.static(distPath));
  app.get('*all', (req, res) => {
    res.sendFile(path.join(distPath, 'index.html'));
  });
}

const PORT = 3000;
httpServer.listen(PORT, "0.0.0.0", () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
